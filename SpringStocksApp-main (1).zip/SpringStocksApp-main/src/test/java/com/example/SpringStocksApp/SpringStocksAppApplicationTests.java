package com.example.SpringStocksApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringStocksAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
